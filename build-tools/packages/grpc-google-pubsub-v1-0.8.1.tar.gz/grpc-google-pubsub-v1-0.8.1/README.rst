gRPC library for google-pubsub-v1

grpc-google-pubsub-v1 is the IDL-derived library for the google-pubsub (v1) service in the googleapis_ repository.

.. _`googleapis`: https://github.com/googleapis/googleapis/tree/master/google/pubsub/v1
