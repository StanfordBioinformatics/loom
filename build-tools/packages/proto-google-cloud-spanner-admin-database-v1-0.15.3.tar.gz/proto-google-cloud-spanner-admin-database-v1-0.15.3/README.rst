gRPC library for Cloud Spanner Database Admin API

proto-google-cloud-spanner-admin-database-v1 is the IDL-derived library for the spanner-admin-database (v1) service in the googleapis_ repository.

.. _`googleapis`: https://github.com/googleapis/googleapis/tree/master/google/spanner/admin/database/v1
