gRPC library for Google Cloud Speech API

proto-google-cloud-speech-v1 is the IDL-derived library for the speech (v1) service in the googleapis_ repository.

.. _`googleapis`: https://github.com/googleapis/googleapis/tree/master/google/cloud/speech/v1
