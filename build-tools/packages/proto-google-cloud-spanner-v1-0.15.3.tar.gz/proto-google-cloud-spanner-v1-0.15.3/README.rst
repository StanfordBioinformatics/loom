gRPC library for Cloud Spanner API

proto-google-cloud-spanner-v1 is the IDL-derived library for the spanner (v1) service in the googleapis_ repository.

.. _`googleapis`: https://github.com/googleapis/googleapis/tree/master/google/spanner/v1
