gRPC library for google-logging-v2

grpc-google-logging-v2 is the IDL-derived library for the google-logging (v2) service in the googleapis_ repository.

.. _`googleapis`: https://github.com/googleapis/googleapis/tree/master/google/logging/v2
