gRPC library for Stackdriver Error Reporting API

proto-google-cloud-error-reporting-v1beta1 is the IDL-derived library for the error-reporting (v1beta1) service in the googleapis_ repository.

.. _`googleapis`: https://github.com/googleapis/googleapis/tree/master/google/devtools/clouderrorreporting/v1beta1
