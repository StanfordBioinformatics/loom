gRPC library for Google Cloud Pub/Sub API

proto-google-cloud-pubsub-v1 is the IDL-derived library for the pubsub (v1) service in the googleapis_ repository.

.. _`googleapis`: https://github.com/googleapis/googleapis/tree/master/google/pubsub/v1
