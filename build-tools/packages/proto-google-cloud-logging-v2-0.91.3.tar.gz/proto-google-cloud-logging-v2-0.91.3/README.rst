gRPC library for Stackdriver Logging API

proto-google-cloud-logging-v2 is the IDL-derived library for the logging (v2) service in the googleapis_ repository.

.. _`googleapis`: https://github.com/googleapis/googleapis/tree/master/google/logging/v2
