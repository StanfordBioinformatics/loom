gRPC library for Cloud Spanner Instance Admin API

proto-google-cloud-spanner-admin-instance-v1 is the IDL-derived library for the spanner-admin-instance (v1) service in the googleapis_ repository.

.. _`googleapis`: https://github.com/googleapis/googleapis/tree/master/google/spanner/admin/instance/v1
