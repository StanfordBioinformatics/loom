var djdt = {jQuery: jQuery};
