Python Client for Cloud Spanner
===============================

    Python idiomatic client for `Cloud Spanner`_.

.. _Cloud Spanner: https://googlecloudplatform.github.io/google-cloud-python/latest/spanner-usage.html


Quick Start
-----------

.. code-block:: console

    $ pip install --upgrade google-cloud-spanner


