gRPC library for Google Cloud Datastore API

proto-google-cloud-datastore-v1 is the IDL-derived library for the datastore (v1) service in the googleapis_ repository.

.. _`googleapis`: https://github.com/googleapis/googleapis/tree/master/google/datastore/v1
